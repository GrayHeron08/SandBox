﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MTEP_Inspector.Util
{
    internal class FileUtil
    {
        internal static bool IsSkipLine(string line)
        {
            if (line.StartsWith("//")
                || line.StartsWith("/*")
                || line.StartsWith("#"))
            {
                return true;
            }

            return false;
        }

        internal static string ToFullPath(string baseDir, string idFilePath)
        {
            bool isRelationPath = false;
            if (idFilePath.StartsWith("."))
            {
                idFilePath = idFilePath.Substring(1);
                isRelationPath = true;
            }
            if (idFilePath.StartsWith(Path.DirectorySeparatorChar.ToString()))
            { 
                idFilePath = idFilePath.Substring(1);
                isRelationPath = true;
            }
            return (isRelationPath == true)
                ? Path.Combine(baseDir, idFilePath)
                : idFilePath;
        }
    }
}
