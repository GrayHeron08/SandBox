﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTEP_Inspector.Util
{
    public class BitUtil
    {
        public static uint MakeMask(int bitLen, int shiftBits)
        {
            var maskBIt = (uint)Math.Pow(2, bitLen) - 1;
            return maskBIt << shiftBits;
        }

        internal static uint Extract(ushort wdData, int startBit, int endBIt)
        {
            var bitLen = Math.Abs(startBit - endBIt);
            var shiftBits = Math.Min(startBit, endBIt);
            var mask = MakeMask(bitLen, shiftBits);
            return wdData & mask;
        }
    }
}
