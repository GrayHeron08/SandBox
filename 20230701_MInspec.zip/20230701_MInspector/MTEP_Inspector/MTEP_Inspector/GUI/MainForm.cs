﻿using MTEP_Inspector.Model.DspDataConfig;
using MTEP_Inspector.Model.LogDataFile;
using System;
using System.Windows.Forms;
using System.Linq;
using System.Drawing;

namespace MTEP_Inspector
{
    public partial class MainForm : Form
    {
        #region Field

        private string mDspDataConfigFilePath = @"D:\source\repo\20230701_MInspector\MTEP_Inspector\サンプル\IDファイル\EMB_DspData.ini";
        private DspDataConfig_Model mDspDataConfig = null;
        private LogFile_Model mLogFile = null;

        #endregion

        public MainForm()
        {
            InitializeComponent();
        }

        #region CallBack

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                LoadDspDataConfig();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mTreeDspConfig_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {
                UpdateDspDataConfigDetail(e.Node);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mLstLogTimeLine_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                LoadLogFrameData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mCmbId_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                UpdateDgv(mCmbId.SelectedItem as IdDataConfig_Model);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mBtnJumpNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (mDgvIdDetail.SelectedCells.Count == 0) { return; }

                var currentCol = mDgvIdDetail.SelectedCells[0].ColumnIndex;
                var currentRow = mDgvIdDetail.SelectedCells[0].RowIndex;

                for (int rowIdx = currentRow + 1; rowIdx < mDgvIdDetail.Rows.Count; rowIdx++)
                {
                    if (mDgvIdDetail[currentCol, rowIdx].Style.BackColor == Color.Orange)
                    {
                        mDgvIdDetail.ClearSelection();
                        mDgvIdDetail.CurrentCell = mDgvIdDetail[currentCol, rowIdx];
                        mDgvIdDetail.Focus();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void mBtnJumpBefore_Click(object sender, EventArgs e)
        {
            try
            {
                if (mDgvIdDetail.SelectedCells.Count == 0) { return; }

                var currentCol = mDgvIdDetail.SelectedCells[0].ColumnIndex;
                var currentRow = mDgvIdDetail.SelectedCells[0].RowIndex;

                for (int rowIdx = currentRow - 1; rowIdx >= 0; rowIdx--)
                {
                    if (mDgvIdDetail[currentCol, rowIdx].Style.BackColor == Color.Orange)
                    {
                        mDgvIdDetail.ClearSelection();
                        mDgvIdDetail.CurrentCell = mDgvIdDetail[currentCol, rowIdx];
                        mDgvIdDetail.Focus();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region MainMenu

        private void menuLoadLogFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                using (var dlg = new OpenFileDialog())
                {
                    if (dlg.ShowDialog() != DialogResult.OK) { return; }
                    LoadLogFile(dlg.FileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region Method

        private void LoadDspDataConfig()
        {
            mDspDataConfig = new Model.DspDataConfig.DspDataConfig_Model(mDspDataConfigFilePath);
            UpdateDspDataConfigTree();
        }

        private void UpdateDspDataConfigTree()
        {
            mTreeDspConfig.Nodes.Clear();
            foreach (var category in mDspDataConfig.GetCategoryList())
            {
                var categoryNode = mTreeDspConfig.Nodes.Add(category);
                foreach (var idData in mDspDataConfig.GetIdConfigList(category))
                {
                    var idNode = categoryNode.Nodes.Add(idData.Label);
                    idNode.Tag = idData;
                }
            }
            mTreeDspConfig.ExpandAll();
        }

        private void UpdateDspDataConfigDetail(TreeNode node)
        {
            mLstDspDataConfigDetail.Items.Clear();
            if (!(node.Tag is IdDataConfig_Model)) { return; }
            foreach (var field in (node.Tag as IdDataConfig_Model).FieldConfigList)
            {
                mLstDspDataConfigDetail.Items.Add(field.Label);
            }
        }

        private void LoadLogFile(string filePath)
        {
            mLogFile = new LogFile_Model(filePath);
            mLstLogTimeLine.DataSource = mLogFile.FrameList;
            mLstLogTimeLine.DisplayMember = "Label";
        }

        private void LoadLogFrameData()
        {
            var logFrame = mLstLogTimeLine.SelectedItem as LogFrame_Model;
            if (logFrame == null) { return; }
            var idConfig = mDspDataConfig.GetIdConfig(logFrame.ID);
            if (idConfig == null) { return; }

            mLstFrameDetail.Items.Clear();

            mLstFrameDetail.Items.Add($"[ {idConfig.Label} ]");
            foreach (var fieldConfig in idConfig.FieldConfigList)
            {
                mLstFrameDetail.Items.Add(
                    string.Join(" ",
                        fieldConfig.WdString,
                        fieldConfig.Name,
                        logFrame.ExtractFieldString(fieldConfig),
                        fieldConfig.Unit));
            }

            var idList = mLogFile.IdTbl.Keys.ToList().ConvertAll(id => mDspDataConfig.GetIdConfig(id));
            idList.Sort((a, b) => a.ID - b.ID);
            mCmbId.DataSource = idList;
            mCmbId.DisplayMember = "Label";
        }

        private void UpdateDgv(IdDataConfig_Model idDataConfig)
        {
            if (idDataConfig == null) { return; }
            mDgvIdDetail.Visible = false;
            mDgvIdDetail.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;

            mDgvIdDetail.Rows.Clear();
            mDgvIdDetail.Columns.Clear();

            var idDataList = mLogFile.IdTbl[idDataConfig.ID];

            foreach (var fieldConfig in idDataConfig.FieldConfigList)
            {
                var idx = idDataConfig.FieldConfigList.IndexOf(fieldConfig);
                var colIdx = mDgvIdDetail.Columns.Add($"{idx}", fieldConfig.MultiLineLabel);
                mDgvIdDetail.Columns[colIdx].SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            for (int dataIdx = 0; dataIdx < idDataList.Count; dataIdx++)
            {
                var rowIdx = mDgvIdDetail.Rows.Add();
                mDgvIdDetail.Rows[rowIdx].HeaderCell.Value = $"{idDataList[dataIdx].TimeSec.ToString()} [sec]";
                for (int fieldIdx = 0; fieldIdx < idDataConfig.FieldConfigList.Count; fieldIdx++)
                {
                    mDgvIdDetail[fieldIdx, rowIdx].Value
                        = idDataList[dataIdx].ExtractFieldString(idDataConfig.FieldConfigList[fieldIdx]);
                }
            }

            SetDiffCellColor();

            mDgvIdDetail.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            mDgvIdDetail.Visible = true;
            mDgvIdDetail.Invalidate();
        }

        private void SetDiffCellColor()
        {
            for (int colIdx = 1; colIdx < mDgvIdDetail.Columns.Count; colIdx++)
            {
                var lastCell = string.Empty;
                for (int rowIdx = 0; rowIdx < mDgvIdDetail.Rows.Count; rowIdx++)
                {
                    var currentCell = mDgvIdDetail[colIdx, rowIdx].EditedFormattedValue.ToString();
                    if (lastCell.Length == 0)
                    {
                        lastCell = currentCell;
                        continue;
                    }
                    if (lastCell == currentCell) { continue; }
                    mDgvIdDetail[colIdx, rowIdx].Style.BackColor = Color.Orange;
                    lastCell = currentCell;
                }
            }
        }

        #endregion
    }

    public class DataGridViewEx : DataGridView
    {
        public DataGridViewEx() : base()
        {
            DoubleBuffered = true;
        }
    }
}
