﻿namespace MTEP_Inspector
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuLoadLogFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.mTabLogTimeLine = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.mLstLogTimeLine = new System.Windows.Forms.ListBox();
            this.mLstFrameDetail = new System.Windows.Forms.ListBox();
            this.mTabIdAnalyze = new System.Windows.Forms.TabPage();
            this.mBtnJumpBefore = new System.Windows.Forms.Button();
            this.mBtnJumpNext = new System.Windows.Forms.Button();
            this.mCmbId = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.mTabIdConfig = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.mTreeDspConfig = new System.Windows.Forms.TreeView();
            this.mLstDspDataConfigDetail = new System.Windows.Forms.ListBox();
            this.mDgvIdDetail = new MTEP_Inspector.DataGridViewEx();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.mTabLogTimeLine.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.mTabIdAnalyze.SuspendLayout();
            this.mTabIdConfig.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mDgvIdDetail)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuFileToolStripMenuItem
            // 
            this.menuFileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuLoadLogFileToolStripMenuItem});
            this.menuFileToolStripMenuItem.Name = "menuFileToolStripMenuItem";
            this.menuFileToolStripMenuItem.Size = new System.Drawing.Size(65, 26);
            this.menuFileToolStripMenuItem.Text = "ファイル";
            // 
            // menuLoadLogFileToolStripMenuItem
            // 
            this.menuLoadLogFileToolStripMenuItem.Name = "menuLoadLogFileToolStripMenuItem";
            this.menuLoadLogFileToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.menuLoadLogFileToolStripMenuItem.Text = "Logファイル読み込み";
            this.menuLoadLogFileToolStripMenuItem.Click += new System.EventHandler(this.menuLoadLogFileToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.mTabLogTimeLine);
            this.tabControl1.Controls.Add(this.mTabIdAnalyze);
            this.tabControl1.Controls.Add(this.mTabIdConfig);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 30);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 420);
            this.tabControl1.TabIndex = 1;
            // 
            // mTabLogTimeLine
            // 
            this.mTabLogTimeLine.Controls.Add(this.splitContainer2);
            this.mTabLogTimeLine.Location = new System.Drawing.Point(4, 25);
            this.mTabLogTimeLine.Name = "mTabLogTimeLine";
            this.mTabLogTimeLine.Padding = new System.Windows.Forms.Padding(3);
            this.mTabLogTimeLine.Size = new System.Drawing.Size(792, 391);
            this.mTabLogTimeLine.TabIndex = 1;
            this.mTabLogTimeLine.Text = "Logタイムライン";
            this.mTabLogTimeLine.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 3);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.mLstLogTimeLine);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.mLstFrameDetail);
            this.splitContainer2.Size = new System.Drawing.Size(786, 385);
            this.splitContainer2.SplitterDistance = 262;
            this.splitContainer2.TabIndex = 1;
            // 
            // mLstLogTimeLine
            // 
            this.mLstLogTimeLine.BackColor = System.Drawing.Color.Black;
            this.mLstLogTimeLine.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mLstLogTimeLine.Font = new System.Drawing.Font("MS UI Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.mLstLogTimeLine.ForeColor = System.Drawing.Color.White;
            this.mLstLogTimeLine.FormattingEnabled = true;
            this.mLstLogTimeLine.ItemHeight = 18;
            this.mLstLogTimeLine.Location = new System.Drawing.Point(0, 0);
            this.mLstLogTimeLine.Name = "mLstLogTimeLine";
            this.mLstLogTimeLine.Size = new System.Drawing.Size(262, 385);
            this.mLstLogTimeLine.TabIndex = 0;
            this.mLstLogTimeLine.SelectedIndexChanged += new System.EventHandler(this.mLstLogTimeLine_SelectedIndexChanged);
            // 
            // mLstFrameDetail
            // 
            this.mLstFrameDetail.BackColor = System.Drawing.Color.Black;
            this.mLstFrameDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mLstFrameDetail.Font = new System.Drawing.Font("MS UI Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.mLstFrameDetail.ForeColor = System.Drawing.Color.White;
            this.mLstFrameDetail.FormattingEnabled = true;
            this.mLstFrameDetail.ItemHeight = 18;
            this.mLstFrameDetail.Location = new System.Drawing.Point(0, 0);
            this.mLstFrameDetail.Name = "mLstFrameDetail";
            this.mLstFrameDetail.Size = new System.Drawing.Size(520, 385);
            this.mLstFrameDetail.TabIndex = 1;
            // 
            // mTabIdAnalyze
            // 
            this.mTabIdAnalyze.BackColor = System.Drawing.Color.Black;
            this.mTabIdAnalyze.Controls.Add(this.mBtnJumpBefore);
            this.mTabIdAnalyze.Controls.Add(this.mBtnJumpNext);
            this.mTabIdAnalyze.Controls.Add(this.mDgvIdDetail);
            this.mTabIdAnalyze.Controls.Add(this.mCmbId);
            this.mTabIdAnalyze.Controls.Add(this.label1);
            this.mTabIdAnalyze.Location = new System.Drawing.Point(4, 25);
            this.mTabIdAnalyze.Name = "mTabIdAnalyze";
            this.mTabIdAnalyze.Padding = new System.Windows.Forms.Padding(3);
            this.mTabIdAnalyze.Size = new System.Drawing.Size(792, 391);
            this.mTabIdAnalyze.TabIndex = 2;
            this.mTabIdAnalyze.Text = "ID解析";
            // 
            // mBtnJumpBefore
            // 
            this.mBtnJumpBefore.Location = new System.Drawing.Point(182, 50);
            this.mBtnJumpBefore.Name = "mBtnJumpBefore";
            this.mBtnJumpBefore.Size = new System.Drawing.Size(120, 35);
            this.mBtnJumpBefore.TabIndex = 4;
            this.mBtnJumpBefore.Text = "Jump &Before";
            this.mBtnJumpBefore.UseVisualStyleBackColor = true;
            this.mBtnJumpBefore.Click += new System.EventHandler(this.mBtnJumpBefore_Click);
            // 
            // mBtnJumpNext
            // 
            this.mBtnJumpNext.Location = new System.Drawing.Point(35, 50);
            this.mBtnJumpNext.Name = "mBtnJumpNext";
            this.mBtnJumpNext.Size = new System.Drawing.Size(120, 35);
            this.mBtnJumpNext.TabIndex = 3;
            this.mBtnJumpNext.Text = "Jump &Next";
            this.mBtnJumpNext.UseVisualStyleBackColor = true;
            this.mBtnJumpNext.Click += new System.EventHandler(this.mBtnJumpNext_Click);
            // 
            // mCmbId
            // 
            this.mCmbId.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mCmbId.Font = new System.Drawing.Font("MS UI Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.mCmbId.FormattingEnabled = true;
            this.mCmbId.Location = new System.Drawing.Point(35, 14);
            this.mCmbId.Name = "mCmbId";
            this.mCmbId.Size = new System.Drawing.Size(376, 26);
            this.mCmbId.TabIndex = 1;
            this.mCmbId.SelectedIndexChanged += new System.EventHandler(this.mCmbId_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(8, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // mTabIdConfig
            // 
            this.mTabIdConfig.Controls.Add(this.splitContainer1);
            this.mTabIdConfig.Location = new System.Drawing.Point(4, 25);
            this.mTabIdConfig.Name = "mTabIdConfig";
            this.mTabIdConfig.Padding = new System.Windows.Forms.Padding(3);
            this.mTabIdConfig.Size = new System.Drawing.Size(792, 393);
            this.mTabIdConfig.TabIndex = 0;
            this.mTabIdConfig.Text = "IDコンフィギュレーション";
            this.mTabIdConfig.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.mTreeDspConfig);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.mLstDspDataConfigDetail);
            this.splitContainer1.Size = new System.Drawing.Size(786, 387);
            this.splitContainer1.SplitterDistance = 262;
            this.splitContainer1.TabIndex = 0;
            // 
            // mTreeDspConfig
            // 
            this.mTreeDspConfig.BackColor = System.Drawing.Color.Black;
            this.mTreeDspConfig.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mTreeDspConfig.Font = new System.Drawing.Font("MS UI Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.mTreeDspConfig.ForeColor = System.Drawing.Color.White;
            this.mTreeDspConfig.Location = new System.Drawing.Point(0, 0);
            this.mTreeDspConfig.Name = "mTreeDspConfig";
            this.mTreeDspConfig.Size = new System.Drawing.Size(262, 387);
            this.mTreeDspConfig.TabIndex = 0;
            this.mTreeDspConfig.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.mTreeDspConfig_AfterSelect);
            // 
            // mLstDspDataConfigDetail
            // 
            this.mLstDspDataConfigDetail.BackColor = System.Drawing.Color.Black;
            this.mLstDspDataConfigDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mLstDspDataConfigDetail.Font = new System.Drawing.Font("MS UI Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.mLstDspDataConfigDetail.ForeColor = System.Drawing.Color.White;
            this.mLstDspDataConfigDetail.FormattingEnabled = true;
            this.mLstDspDataConfigDetail.ItemHeight = 18;
            this.mLstDspDataConfigDetail.Location = new System.Drawing.Point(0, 0);
            this.mLstDspDataConfigDetail.Name = "mLstDspDataConfigDetail";
            this.mLstDspDataConfigDetail.ScrollAlwaysVisible = true;
            this.mLstDspDataConfigDetail.Size = new System.Drawing.Size(520, 387);
            this.mLstDspDataConfigDetail.TabIndex = 0;
            // 
            // mDgvIdDetail
            // 
            this.mDgvIdDetail.AllowUserToAddRows = false;
            this.mDgvIdDetail.AllowUserToDeleteRows = false;
            this.mDgvIdDetail.AllowUserToResizeRows = false;
            this.mDgvIdDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.mDgvIdDetail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.mDgvIdDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mDgvIdDetail.Location = new System.Drawing.Point(11, 91);
            this.mDgvIdDetail.Name = "mDgvIdDetail";
            this.mDgvIdDetail.ReadOnly = true;
            this.mDgvIdDetail.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.mDgvIdDetail.RowTemplate.Height = 24;
            this.mDgvIdDetail.Size = new System.Drawing.Size(773, 292);
            this.mDgvIdDetail.TabIndex = 2;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.mTabLogTimeLine.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.mTabIdAnalyze.ResumeLayout(false);
            this.mTabIdAnalyze.PerformLayout();
            this.mTabIdConfig.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mDgvIdDetail)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage mTabIdConfig;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView mTreeDspConfig;
        private System.Windows.Forms.TabPage mTabLogTimeLine;
        private System.Windows.Forms.ListBox mLstDspDataConfigDetail;
        private System.Windows.Forms.ToolStripMenuItem menuFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuLoadLogFileToolStripMenuItem;
        private System.Windows.Forms.ListBox mLstLogTimeLine;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ListBox mLstFrameDetail;
        private System.Windows.Forms.TabPage mTabIdAnalyze;
        private System.Windows.Forms.ComboBox mCmbId;
        private System.Windows.Forms.Label label1;
        private DataGridViewEx mDgvIdDetail;
        private System.Windows.Forms.Button mBtnJumpBefore;
        private System.Windows.Forms.Button mBtnJumpNext;
    }
}

