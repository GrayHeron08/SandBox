﻿namespace MTEP_Inspector.Model.LogDataFile
{
    public static class LogField_StringUtil
    {
        public static string ExtractFieldString(this LogFrame_Model logFrame, DspDataConfig.FieldDataConfig_Model fieldConfig)
        {
            var data = logFrame.ExtractFieldData(fieldConfig);
            string dataString = data.ToString();
            if (fieldConfig.IsHex)
            {
                dataString = $"0x{string.Format("{0:X04}", (uint)data)}";
            }
            return dataString;
        }
    }
}
