﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MTEP_Inspector.Model.DspDataConfig;

namespace MTEP_Inspector.Model.LogDataFile
{
    public static class LogFile_Extractor
    {
        public static double ExtractFieldData(this LogFrame_Model logFrame, FieldDataConfig_Model fieldConfig)
        {
            var wdData = logFrame.Data[fieldConfig.WD];
            var tmpData = Util.BitUtil.Extract(wdData, fieldConfig.StartBit, fieldConfig.EndBIt);
            var data = (fieldConfig.Sign == 1
                ? BitConverter.ToInt32(BitConverter.GetBytes(tmpData), 0)
                : (int)tmpData) * fieldConfig.LSB;
            return data;
        }
    }
}
