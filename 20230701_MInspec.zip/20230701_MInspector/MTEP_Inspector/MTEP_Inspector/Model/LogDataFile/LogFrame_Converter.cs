﻿using System;

namespace MTEP_Inspector.Model.LogDataFile
{
    internal static class LogFrame_Converter
    {
        public static void Decode(this LogFrame_Model logFrame, double timeLsbMSec, byte[] data)
        {

            var timeArry = new byte[LogFrame_Model.FRAME_HEADER_BYTES];
            Array.Copy(data, 1, timeArry, 0, 3);
            logFrame.Setup((uint)(BitConverter.ToUInt32(timeArry, 0) * timeLsbMSec), data[0]);

            var tmpData = new byte[LogFrame_Model.DATA_BYTE_NUM];
            Array.Copy(data, LogFrame_Model.FRAME_HEADER_BYTES, tmpData, 0, LogFrame_Model.DATA_BYTE_NUM);
            for (int i = 0; i < LogFrame_Model.DATA_BYTE_NUM; i += LogFrame_Model.BYTES_OF_WD)
            {
                logFrame.Data[i / LogFrame_Model.BYTES_OF_WD] = BitConverter.ToUInt16(tmpData, i);
            }
        }
    }
}
