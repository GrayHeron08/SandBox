﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTEP_Inspector.Model.LogDataFile
{
    /// <summary>
    /// ログFrameクラス
    /// </summary>
    public class LogFrame_Model
    {
        #region 定数

        /// <summary> WD数 </summary>
        public static readonly int DATA_WD_NUM = 32;
        /// <summary> フレームヘッダbyteサイズ </summary>
        public static readonly int FRAME_HEADER_BYTES = 4;
        /// <summary> 1WDあたりのbyte数 </summary>
        public static readonly int BYTES_OF_WD = 2;
        /// <summary> WDのbyte数 </summary>
        public static readonly int DATA_BYTE_NUM = LogFrame_Model.DATA_WD_NUM * BYTES_OF_WD;
        /// <summary> 1フレームあたりのbyteサイズ </summary>
        public static readonly int FRAME_BYTES = DATA_BYTE_NUM + FRAME_HEADER_BYTES;

        #endregion

        #region プロパティ

        /// <summary> データインデックス </summary>
        public int Index { get; protected set; } = 0;
        /// <summary> ID </summary>
        public int ID { get; protected set; } = 0;
        /// <summary> タイムスタンプ[msec] </summary>
        public ulong TimeMSec { get; protected set; } = 0;
        /// <summary> タイムスタンプ[sec] </summary>
        public double TimeSec => TimeMSec / 1000.0;
        /// <summary> データ配列 </summary>
        public ushort[] Data { get; protected set; } = new ushort[DATA_WD_NUM];

        /// <summary> 表示用文字列 </summary>
        public string Label => this.ToListString();
        /// <summary> 16進数データ文字列 </summary>
        public string HexData => this.ToHexDataString();

        #endregion

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="timeLsbMSec">タイムスタンプLSB[msec]</param>
        /// <param name="idx">データインデックス</param>
        /// <param name="data">データ配列</param>
        public LogFrame_Model(double timeLsbMSec, int idx, byte[] data)
        {
            Index = idx;
            this.Decode(timeLsbMSec, data);
        }

        #region メソッド

        public void Setup(ulong timeMSec, int id)
        {
            TimeMSec = timeMSec;
            ID = id;
        }

        /// <summary>
        /// データ生成処理
        /// </summary>
        /// <param name="timeLsbMSec">タイムスタンプLSB[msec]</param>
        /// <param name="id">ID</param>
        /// <param name="timeMSec">タイムスタンプ[msec]</param>
        /// <param name="dataArry">データ配列</param>
        public static byte[] CreateLogFrame(double timeLsbMSec, int id, ulong timeMSec, ushort[] dataArry)
        {
            var createdData = new byte[FRAME_BYTES];
            if (dataArry.Length != DATA_WD_NUM) { throw new FormatException(); }
            createdData[0] = (byte)id;
            var timeArry = BitConverter.GetBytes(Math.Round(timeMSec / timeLsbMSec));
            Array.Copy(timeArry, 0, createdData, 1, 3);
            for (int i = 0; i < DATA_BYTE_NUM; i += BYTES_OF_WD)
            {
                var dataBytes = BitConverter.GetBytes(dataArry[i / BYTES_OF_WD]);
                createdData[FRAME_HEADER_BYTES + i] = dataBytes[0];
                createdData[FRAME_HEADER_BYTES + i + 1] = dataBytes[1];
            }
            return createdData;
        }

        #endregion
    }
}
