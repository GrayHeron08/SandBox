﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTEP_Inspector.Model.LogDataFile
{
    public static class LogFrame_StringUtil
    {
        /// <summary>
        /// 表示用文字列生成処理
        /// </summary>
        /// <returns>表示用文字列</returns>
        public static string ToListString(this LogFrame_Model logFrame)
        {
            return string.Format("{0:D04} {1:F3} ID{2:D02}", logFrame.Index, logFrame.TimeSec, logFrame.ID);
        }

        /// <summary>
        /// 16進数データ文字列生成処理
        /// </summary>
        /// <returns>16進数データ文字列</returns>
        public static string ToHexDataString(this LogFrame_Model logFrame)
        {
            var sb = new StringBuilder();
            for (int wd = 0; wd < logFrame.Data.Length; wd++)
            {
                sb.AppendFormat("WD{0:D02} 0x{1:X04}", wd, logFrame.Data[wd])
                    .AppendLine();
            }
            return sb.ToString();
        }

    }
}
