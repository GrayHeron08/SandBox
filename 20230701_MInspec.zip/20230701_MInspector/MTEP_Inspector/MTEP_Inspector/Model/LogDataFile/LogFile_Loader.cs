﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTEP_Inspector.Model.LogDataFile
{
    public static class LogFile_Loader
    {
        /// <summary>
        /// ファイル読み込み処理
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        internal static void ReadFile(this LogFile_Model logFile, string filePath)
        {
            using (var br = new BinaryReader(new FileStream(filePath, FileMode.Open)))
            {
                var fileHeaderBytes = br.ReadBytes(LogFile_Model.FILE_HEADER_BYTES);
                logFile.SetupLogInfo(
                    fileHeaderBytes[LogFile_Model.LOCATION_OF_FILE_VER],
                    fileHeaderBytes[LogFile_Model.LOCATION_OF_LSB_FLAG]);
                var timeLsbMSec = logFile.LsbFlag == 1 ? LogFile_Model.TIME_LSB_MSEC_1 : LogFile_Model.TIME_LSB_MSEC_2;
                var frameNum = (int)BitConverter.ToUInt32(br.ReadBytes(LogFile_Model.FRAME_NUM_BYTES), 0) / LogFrame_Model.FRAME_BYTES;

                foreach (var idx in Enumerable.Range(0, frameNum))
                {
                    logFile.AddFrame(new LogFrame_Model(timeLsbMSec, logFile.FrameList.Count, br.ReadBytes(LogFrame_Model.FRAME_BYTES)));
                }
            }
        }
    }
}
