﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;

namespace MTEP_Inspector.Model.LogDataFile
{
    /// <summary>
    /// ログファイルクラス
    /// </summary>
    public class LogFile_Model
    {
        #region 定数

        /// <summary> サイズ定義 ファイルヘッダ </summary>
        internal static readonly int FILE_HEADER_BYTES = 134;
        /// <summary> サイズ定義 フレーム数 </summary>
        internal static readonly int FRAME_NUM_BYTES = 4;

        /// <summary> ログファイルバージョン位置 </summary>
        internal static readonly int LOCATION_OF_FILE_VER = 12;
        /// <summary> LSBフラグ位置 </summary>
        internal static readonly int LOCATION_OF_LSB_FLAG = 14;

        internal static readonly double TIME_LSB_MSEC_1 = 1;
        internal static readonly double TIME_LSB_MSEC_2 = 2;

        #endregion

        #region メンバ変数

        /// <summary> LogFrameリスト </summary>
        private List<LogFrame_Model> mFrameLsit = new List<LogFrame_Model>();
        /// <summary> IDテーブル </summary>
        private Dictionary<int, List<LogFrame_Model>> mIdTbl = new Dictionary<int, List<LogFrame_Model>>();

        #endregion

        #region プロパティ

        /// <summary> ファイルパス </summary>
        public string FilePath { get; protected set; } = string.Empty;
        /// <summary> Frameリスト </summary>
        public ReadOnlyCollection<LogFrame_Model> FrameList
            => mFrameLsit.AsReadOnly();
        /// <summary> IDテーブル </summary>
        public ReadOnlyDictionary<int, List<LogFrame_Model>> IdTbl
        {
            get
            {
                return new ReadOnlyDictionary<int, List<LogFrame_Model>>(mIdTbl);
            }
        }

        /// <summary> ログファイルバージョン </summary>
        public int LogFileVersion { get; protected set; } = 0;

        /// <summary> LSBフラグ </summary>
        public int LsbFlag { get; protected set; } = 0;

        #endregion

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        public LogFile_Model(string filePath)
        {
            FilePath = filePath;
            this.ReadFile(filePath);
            CreateIdTbl();
        }

        #region メソッド

        internal void SetupLogInfo(byte fileVersion, byte lsbFlag)
        {
            LogFileVersion = fileVersion;
            LsbFlag = lsbFlag;
        }

        internal void AddFrame(LogFrame_Model logFrame)
        {
            mFrameLsit.Add(logFrame);
        }

        /// <summary>
        /// IDテーブル作成処理
        /// </summary>
        private void CreateIdTbl()
        {
            mIdTbl.Clear();
            foreach (var g in mFrameLsit.GroupBy(tbl => tbl.ID))
            {
                mIdTbl[g.Key] = g.ToList();
            }
        }

        #endregion
    }
}
