﻿using System;

namespace MTEP_Inspector.Model.DspDataConfig
{
    public static class FieldDataConfig_Loader
    {
        #region enum

        private enum EnumLineCol
        {
            WD = 0,
            StartBit,
            EndBit,
            FieldName,
            Sign,
            Unit,
            LSB,
            MinValue,
            MaxValue,

            Count
        }

        #endregion

        #region Method

        public static void DecodeLine(this FieldDataConfig_Model field, string line)
        {
            var sp_line = line.Split('\t');
            if ((int)EnumLineCol.Count != sp_line.Length)
            {
                throw new FormatException($"Illegal format . {Environment.NewLine}{line}");
            }

            field.Apply(
                sp_line[(int)EnumLineCol.FieldName],
                int.Parse(sp_line[(int)EnumLineCol.WD]),
                int.Parse(sp_line[(int)EnumLineCol.StartBit]),
                int.Parse(sp_line[(int)EnumLineCol.EndBit]),
                int.Parse(sp_line[(int)EnumLineCol.Sign]),
                double.Parse(sp_line[(int)EnumLineCol.LSB]),
                sp_line[(int)EnumLineCol.Unit],
                double.Parse(sp_line[(int)EnumLineCol.MinValue]),
                double.Parse(sp_line[(int)EnumLineCol.MaxValue]));
        }

        #endregion
    }
}
