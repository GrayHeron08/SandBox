﻿using MTEP_Inspector.Util;
using System.IO;
using System.Text;

namespace MTEP_Inspector.Model.DspDataConfig
{
    public static class IdDataConfig_Loarder
    {
        #region enum

        private enum EnumLineCol
        {
            Empty = 0,
            IdString,
            DataName,
            Id,
            IdFilePath
        }

        #endregion

        #region Method

        public static void DecodeLine(this IdDataConfig_Model idDataConfig, string line, string baseDirPath, ref string idFilePath)
        {
            var sp_line = line.Split('\t');
            idFilePath = sp_line[(int)EnumLineCol.IdFilePath];
            idFilePath = FileUtil.ToFullPath(baseDirPath, idFilePath);

            idDataConfig.Apply(
                idFilePath,
                sp_line[(int)EnumLineCol.IdString],
                sp_line[(int)EnumLineCol.DataName],
                int.Parse(sp_line[(int)EnumLineCol.Id]));
            idDataConfig.Read(idFilePath);
        }

        public static void Read(this IdDataConfig_Model idDataConfig, string filePath)
        {
            var lines = File.ReadLines(filePath, Encoding.Default);
            idDataConfig.Clear();
            foreach (var line in lines)
            {
                if (FileUtil.IsSkipLine(line)) { continue; }
                idDataConfig.AddFieldConfig(new FieldDataConfig_Model(line));
            }
        }

        #endregion
    }
}
