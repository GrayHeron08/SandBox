﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace MTEP_Inspector.Model.DspDataConfig
{
    public class IdDataConfig_Model
    {
        #region Field

        protected List<FieldDataConfig_Model> mFieldConfigList = new List<FieldDataConfig_Model>();

        #endregion

        #region Property

        public string Category { get; protected set; } = string.Empty;
        public string FilePath { get; protected set; } = string.Empty;
        public string IdString { get; protected set; } = string.Empty;
        public string DataName { get; protected set; } = string.Empty;
        public int ID { get; protected set; } = -1;

        public ReadOnlyCollection<FieldDataConfig_Model> FieldConfigList => mFieldConfigList.AsReadOnly();

        public string Label => $"{IdString} {DataName}";

        #endregion

        public IdDataConfig_Model(string category, string baseDir, string line)
        {
            var idFilePath = string.Empty;
            Category = category;

            this.DecodeLine(line, baseDir, ref idFilePath);
        }

        #region Method

        public void Apply(string filePath, string idString, string dataName, int id)
        {
            FilePath = filePath;
            IdString = idString;
            DataName = dataName;
            ID = id;
    }

    public void Clear()
        {
            mFieldConfigList.Clear();
        }

        public void AddFieldConfig(FieldDataConfig_Model fieldConfig)
        {
            mFieldConfigList.Add(fieldConfig);
        }

        #endregion
    }
}
