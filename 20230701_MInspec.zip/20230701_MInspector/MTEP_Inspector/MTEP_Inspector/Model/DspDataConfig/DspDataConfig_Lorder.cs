﻿using MTEP_Inspector.Util;
using System.IO;
using System.Linq;
using System.Text;

namespace MTEP_Inspector.Model.DspDataConfig
{
    public static class DspDataConfig_Lorder
    {

        public static void Read(this DspDataConfig_Model dspDataConfig, string filePath)
        {
            var lines = File.ReadLines(filePath, Encoding.Default);
            var baseDirPath = Path.GetDirectoryName(filePath);
            var lastCategory = string.Empty;

            dspDataConfig.Clear();
            foreach (var line in lines)
            {
                if (FileUtil.IsSkipLine(line)) { continue; }

                var sp_line = line.Split('\t');
                if (line.StartsWith("\t"))
                {
                    dspDataConfig.AddIdConfig(new IdDataConfig_Model(lastCategory, baseDirPath, line));
                }
                else
                {
                    lastCategory = sp_line.First();
                }
            }
        }
    }
}
