﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace MTEP_Inspector.Model.DspDataConfig
{
    public class DspDataConfig_Model
    {
        #region Field

        protected List<IdDataConfig_Model> mIdConfigList = new List<IdDataConfig_Model>();

        #endregion

        #region Property

        public string FIlePath { get; protected set; } = string.Empty;
        public ReadOnlyCollection<IdDataConfig_Model> IdConfigList
            => mIdConfigList.AsReadOnly();

        #endregion

        public DspDataConfig_Model(string filePath)
        {
            this.Read(filePath);
            FIlePath = filePath;
        }

        #region Method

        public void Clear()
        {
            mIdConfigList.Clear();
        }

        public void AddIdConfig(IdDataConfig_Model idConfig)
        {
            mIdConfigList.Add(idConfig);
        }

        #endregion
    }
}
