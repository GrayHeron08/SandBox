﻿using System.Collections.Generic;
using System.Linq;

namespace MTEP_Inspector.Model.DspDataConfig
{
    public static class DspData_Searcher
    {
        public static IEnumerable<string> GetCategoryList(this DspDataConfig_Model dspDataConfig)
        {
            return dspDataConfig.IdConfigList
                .ToList().ConvertAll(id => id.Category)
                .Distinct();
        }

        public static IEnumerable<string> GetIdStringList(this DspDataConfig_Model dspDataConfig)
        {
            return dspDataConfig.IdConfigList
                .ToList().ConvertAll(id => id.IdString);
        }

        public static IEnumerable<string> GetIdStringList(this DspDataConfig_Model dspDataConfig, string category)
        {
            return dspDataConfig.IdConfigList
                .Where(id => id.Category == category)
                .ToList().ConvertAll(id => id.IdString);
        }

        public static IEnumerable<string> GetIdDataNameList(this DspDataConfig_Model dspDtaConfig)
        {
            return dspDtaConfig.IdConfigList
                .ToList().ConvertAll(id => id.DataName);
        }

        public static IEnumerable<string> GetIdDataNameList(this DspDataConfig_Model dspDtaConfig, string category)
        {
            return dspDtaConfig.IdConfigList
                .Where(id => id.Category == category)
                .ToList().ConvertAll(id => id.DataName);
        }

        public static IEnumerable<IdDataConfig_Model> GetIdConfigList(this DspDataConfig_Model dspDataConfig, string category)
        {
            return dspDataConfig.IdConfigList
                .Where(id => id.Category == category);
        }

        public static IdDataConfig_Model GetIdConfig(this DspDataConfig_Model dspDataConfig, int id)
        {
            return dspDataConfig.IdConfigList.FirstOrDefault(idConfig => idConfig.ID == id);
        }
    }
}
