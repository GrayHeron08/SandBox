﻿namespace MTEP_Inspector.Model.DspDataConfig
{
    public class FieldDataConfig_Model
    {
        #region Property

        public string Name { get; protected set; } = string.Empty;
        public int WD { get; protected set; } = -1;
        public int StartBit { get; protected set; } = -1;
        public int EndBIt { get; protected set; } = -1;
        public int Sign { get; protected set; } = 0;
        public double LSB { get; protected set; } = 1.0;
        public string Unit { get; protected set; } = "-";
        public double MinValue { get; protected set; } = 0.0;
        public double MaxValue { get; protected set; } = 0.0;

        public string Label
            => string.Format("WD{0:d02} BIT{1:d02}-{2:d02} {3}", WD, StartBit, EndBIt, Name);
        public string MultiLineLabel
            => string.Format("WD{0:d02}\r\nBIT{1:d02}-{2:d02}\r\n{3}\r\n{4}", WD, StartBit, EndBIt, Name, Unit);


        public string WdString => $"WD{string.Format("{0:d02}", WD)}";

        public bool IsHex => Unit == "[HEX]";

        #endregion

        public FieldDataConfig_Model() { }

        public FieldDataConfig_Model(string line)
        {
            this.DecodeLine(line);
        }

        #region Method

        public void Apply(string name, int wd, int startBit, int endBit, int sign, double lsb, string unit,
            double minValue, double maxValue)
        {
            Name = name;
            WD = wd;
            StartBit = startBit;
            EndBIt = endBit;
            Sign = sign;
            LSB = lsb;
            Unit = unit;
            MinValue = minValue;
            MaxValue = maxValue;
        }

        #endregion
    }
}
