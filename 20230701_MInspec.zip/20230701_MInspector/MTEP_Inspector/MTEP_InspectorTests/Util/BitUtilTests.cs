﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MTEP_Inspector.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTEP_Inspector.Util.Tests
{
    [TestClass()]
    public class BitUtilTests
    {
        [TestMethod()]
        [DataRow(0,     0,      0)]
        [DataRow(1,     0,      1)]
        [DataRow(2,     0,      3)]
        [DataRow(3,     0,      7)]
        [DataRow(4,     0,      15)]
        [DataRow(5,     0,      31)]
        [DataRow(6,     0,      63)]
        [DataRow(7,     0,      127)]
        [DataRow(8,     0,      255)]
        [DataRow(16,   0,      65535)]

        [DataRow(2,     1,      6)]
        [DataRow(2,     2,      12)]
        [DataRow(2,     3,      24)]
        [DataRow(2,     4,      48)]
        [DataRow(2,     5,      96)]
        [DataRow(2,     6,      192)]
        [DataRow(2,     7,      384)]
        [DataRow(2,     8,      768)]
        [DataRow(2,     16,     196608)]
        public void MakeMaskTest(int bitLen, int shiftBits, int expMask)
        {
            var mask = BitUtil.MakeMask(bitLen, shiftBits);
            Assert.AreEqual((uint)expMask, mask);
        }
    }
}