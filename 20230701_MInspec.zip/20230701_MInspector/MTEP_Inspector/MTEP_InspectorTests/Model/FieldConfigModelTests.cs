﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MTEP_Inspector.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MTEP_Inspector.Model.DspDataConfig.Tests
{
    [TestClass()]
    public class FieldConfigModelTests
    {
        [TestMethod()]
        public void デフォルトコンストラクタ()
        {
            var field = new FieldDataConfig_Model();
            Assert.IsNotNull(field);
            Assert.AreEqual("", field.Name);
            Assert.AreEqual(-1, field.WD);
            Assert.AreEqual(-1, field.StartBit);
            Assert.AreEqual(-1, field.EndBIt);
            Assert.AreEqual(0, field.Sign);
            Assert.AreEqual(1.0, field.LSB, double.Epsilon);
            Assert.AreEqual("-", field.Unit);
            Assert.AreEqual(0.0, field.MinValue, double.Epsilon);
            Assert.AreEqual(0.0, field.MaxValue, double.Epsilon);
        }

        [TestMethod]
        [DataRow("4\t15\t0\t舵角指令#1\t0\t[deg]\t0.001037598\t-34\t34\r\n")]
        public void コンストラクタ(string line)
        {
            var field = new FieldDataConfig_Model(line);
            Assert.IsNotNull(field);
            Assert.AreEqual("舵角指令#1", field.Name);
            Assert.AreEqual(4, field.WD);
            Assert.AreEqual(15, field.StartBit);
            Assert.AreEqual(0, field.EndBIt);
            Assert.AreEqual(0, field.Sign);
            Assert.AreEqual(0.001037598, field.LSB, double.Epsilon);
            Assert.AreEqual("[deg]", field.Unit);
            Assert.AreEqual(-34.0, field.MinValue, double.Epsilon);
            Assert.AreEqual(34.0, field.MaxValue, double.Epsilon);
        }
    }
}